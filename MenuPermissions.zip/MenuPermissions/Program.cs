﻿using Newtonsoft.Json;
using System;
using System.Text.Json;
namespace MenuPermissions
{    
    public class Program
    {
        static void Main(string[] args)
        {
            try
            {
                if (args.Length == 2) 
                {
                    //string menuFilePath = Path.Combine(Environment.CurrentDirectory, "menus.txt");//
                    //string userFilePath = Path.Combine(Environment.CurrentDirectory, "users.txt");//

                    string userFilePath = Path.Combine(Environment.CurrentDirectory, args[0]);
                    string menuFilePath = Path.Combine(Environment.CurrentDirectory, args[1]);
                    
                    //check if the file's extenssion is .txt
                    if ((Path.GetExtension(menuFilePath).ToLower() == ".txt") && (Path.GetExtension(userFilePath).ToLower() == ".txt"))
                    {
                        //dictionnary that takes menu order number as type, and manu name as value
                        if (File.Exists(menuFilePath) && File.Exists(userFilePath))
                        {
                            Dictionary<int, string> dicMenu = GetListOfMenus(menuFilePath);

                            List<UserPermission> userPermissions = GetUserPermissions(userFilePath);

                            //Generate json file
                            GenerateJsonFile(dicMenu, userPermissions); 
                        }
                        else
                        {
                            Console.WriteLine($"There is a file missing.");
                        }  
                    }
                    else
                    {
                        Console.WriteLine($"One of the two files entered is not a '.txt' file.");
                    } 
                }
                else 
                {
                    Console.WriteLine($"\n\nThis application has been configured to run using command line");
                    Console.WriteLine($"Please check if you have runned it with input two parameters.");
                }
            }
            catch (Exception)
            {
                //Log the error here if something happens
                Console.WriteLine($"An error has occured, please contact us");
                throw;
            }
           
            //Console.ReadKey();
        }

        /// <summary>
        /// Validate Menu File
        /// </summary>
        /// <param name="menuFilePath"></param>
        /// <returns></returns>
        public static Dictionary<int,string> GetListOfMenus( string menuFilePath)
        {

            //dictionnary that takes menu order number as type, and manu name as value
            Dictionary<int, string> dicMenu = new(10);
            try
            {
                //check if the file exist before proceding
                if (File.Exists(menuFilePath))
                {
                    using (StreamReader reader = new(menuFilePath))
                    {
                        string line;

                        while ((line = reader.ReadLine()) != null)
                        {
                            line = line.Trim();

                            //continue to next line if it hapens the line is empty
                            if (String.IsNullOrWhiteSpace(line))
                                continue;

                            //this is just another check to verify if line starts with an integer
                            string[] aline = line.Split(',');
                            if ((aline.Length > 1) && (int.TryParse(aline[0], out int pos)))
                            {
                                dicMenu.Add(pos, aline[1].Trim());
                            }
                            else
                            {
                                Console.WriteLine($"Something is wrong in the line. for now we continue to the nwext line");
                                continue;
                            }

                            //Console.WriteLine($"{line}");
                        }
                    }
                }
                else
                {
                    Console.WriteLine($"the file '{Path.GetFileName(menuFilePath)}' does not exist.");
                }
            }
            catch
            {
                //error need to be handled here if something happens
                Console.WriteLine($"An error has occured, it needs to be logged here.");
                throw;
            }
            return dicMenu;
        }

        /// <summary>
        /// Validate User Permission File
        /// </summary>
        /// <param name="userFilePath"></param>
        /// <returns></returns>
        public static List<UserPermission> GetUserPermissions(string userFilePath)
        {
            List<UserPermission> userPermissions = new();
            try
            {
                if (File.Exists(userFilePath))
                {
                    using (StreamReader reader = new(userFilePath))
                    {
                        string line;
                        while ((line = reader.ReadLine()) != null)
                        {
                            line = line.Trim();

                            //continue to the next line if the line is empy
                            if (String.IsNullOrWhiteSpace(line))
                                continue;
                            string[] aline = line.Split(" ");
                            UserPermission userPermission = new()
                            {
                                UserName = aline[0],
                                PermissionString = aline[1] + aline[2]
                            };
                            userPermissions.Add(userPermission);
                        }
                    }
                }
                else
                {
                    Console.WriteLine($"the file '{Path.GetFileName(userFilePath)}' does not exist.");
                }
            }
            catch (Exception)
            {

                throw;
            }
            return userPermissions;
        }

        /// <summary>
        /// Generate Json file
        /// </summary>
        /// <param name="dicMenu"></param>
        /// <param name="userPermissions"></param>
        public static void GenerateJsonFile(Dictionary<int,string> dicMenu, List<UserPermission> userPermissions)
        {
            List<User> users = new();

            //string testJsonFilePath = @"D:\Projects\MenuPermissions\testJson.json";
            try
            {
                foreach (var up in userPermissions)
                {
                    User user = new();
                    user.UserName = up.UserName;
                    int count = 1;
                    foreach (char c in up.PermissionString)
                    {
                        if (c == 'Y')
                        {
                            user.MenuItems.Add(dicMenu[count]);
                        }
                        count += 1;
                    }
                    users.Add(user);
                }

                //added to the root class
                MainUser main_users = new() 
                {
                    Users = users
                };
                
                JsonSerializerOptions options = new JsonSerializerOptions
                {
                   WriteIndented = true,
                   PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
                };
                string strJson = System.Text.Json.JsonSerializer.Serialize(main_users, options);
                Console.WriteLine(strJson);

                //using (StreamWriter sw = new(testJsonFilePath))
                //{
                //    sw.Write(strJson);
                //}
            }
            catch (Exception)
            {
                throw;
            }
        }
    }

    public class MainUser
    {
        public List<User> Users { get; set; } = new();
    }
    /// <summary>
    /// user class
    /// </summary>
    public class User
    {
        /// <summary>
        /// user name
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// list of menu
        /// </summary>
        public List<string> MenuItems { get; set; } = new();
    }

    public class UserPermission
    {
        /// <summary>
        /// User Name
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// Permission string
        /// </summary>
        public string PermissionString {  get; set; }
    }

}

